﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Services;
using DemoProject_Template_DU.DbUtilityDB;
using System.Web.Script.Services;
using MongoDB.Bson;


namespace StudentRegistrationApp16.Views
{
	public partial class StudentRegistrationDetails : System.Web.UI.Page
	{
		static DbUtility oDAl = new DbUtility();
 		protected void Page_Load(object sender, EventArgs e)
		{

		}
		
		[WebMethod]
		public static bool saveStudent(string StudentObj)
		{
			return oDAl.SaveDocument(StudentObj, "Student");
		}

		[WebMethod]
		[ScriptMethod(UseHttpGet = true)]
		public static string getAllStudents()
		{
			return oDAl.GetAllDocumentsWithObjectId("Student");
		}

		[WebMethod]
		public static string findStudentById(string sid)
		{
			return oDAl.GetDocumentByIdWithObjectId("Student","_id",ObjectId.Parse(sid));
		}

		[WebMethod]
		public static bool updateStudent(string StudentObj)
		{
			return oDAl.UpdateDocumentByObjectId(StudentObj, "Student");
		}

		[WebMethod]
		public static bool deleteStudent(string sid)
		{
			return oDAl.DeleteDocumentByObjectId("Student", ObjectId.Parse(sid));
		}

		[WebMethod]
		public static bool saveLocalToDatabase(string StudentObj)
		{
			return oDAl.SaveDocumentBsonArray(StudentObj, "Student");
		}
	}
}